package com.ankitsubhamjyoti.smc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmcApplication.class, args);
	}

}
